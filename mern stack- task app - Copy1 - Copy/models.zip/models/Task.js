const mongoose = require("mongoose");

const subTaskSchema = new mongoose.Schema({
  title: { type: String, required: true },
  isCompleted: { type: Boolean, default: false },
});

const taskSchema = new mongoose.Schema({
  category: { type: String, required: true }, // e.g., "Education", "Work", etc.
  title: { type: String, required: true },    // e.g., "Learn Java"
  isCompleted: { type: Boolean, default: false },
  subTasks: [subTaskSchema],
  createdAt: { type: Date, default: Date.now },
  dueDate: { type: Date }, // optional, in case you want to track deadlines
});

module.exports = mongoose.model("Task", taskSchema);
