const Task = require("../models/Task");

// GET all tasks
exports.getAllTasks = async (req, res) => {
  try {
    const tasks = await Task.find();
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ error: "Server error" });
  }
};

// CREATE a task
exports.createTask = async (req, res) => {
  try {
    const { category, title, subTasks } = req.body;
    const newTask = new Task({ category, title, subTasks });
    await newTask.save();
    res.json(newTask);
  } catch (error) {
    res.status(500).json({ error: "Server error" });
  }
};

// UPDATE a task
exports.updateTask = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedTask = await Task.findByIdAndUpdate(id, req.body, { new: true });
    res.json(updatedTask);
  } catch (error) {
    res.status(500).json({ error: "Server error" });
  }
};

// DELETE a task
exports.deleteTask = async (req, res) => {
  try {
    const { id } = req.params;
    await Task.findByIdAndDelete(id);
    res.json({ message: "Task deleted" });
  } catch (error) {
    res.status(500).json({ error: "Server error" });
  }
};

// OPTIONAL: automatically generate tasks if none for a day
// in taskController.js
exports.autoGenerateTasksForDay = async (req, res) => {
    try {
      const { date } = req.body; 
      // Query for tasks with that date (depending on how you store it)
      const tasksForDay = await Task.find({ dueDate: date });
      
      // If no tasks, create default tasks
      if (tasksForDay.length === 0) {
        const defaultTasks = [
          { category: "Education", title: "Learn Java" },
          { category: "Health", title: "Morning Yoga" },
          // ... more tasks
        ];
        await Task.insertMany(defaultTasks.map(t => ({ ...t, dueDate: date })));
        return res.json({ message: "Default tasks created" });
      } else {
        return res.json({ message: "Tasks already exist for that date" });
      }
    } catch (error) {
      res.status(500).json({ error: "Server error" });
    }
  };
  
