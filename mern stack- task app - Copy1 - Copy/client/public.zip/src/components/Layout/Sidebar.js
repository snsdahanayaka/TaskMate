import React from "react";
import { FaHome, FaTasks, FaCog } from "react-icons/fa"; // example icons

const Sidebar = () => {
  return (
    <aside style={styles.sidebar}>
      <div style={styles.logo}>TaskMate</div>
      <nav style={styles.nav}>
        <ul>
          <li><FaHome /> Home</li>
          <li><FaTasks /> Tasks</li>
          <li><FaCog /> Settings</li>
        </ul>
      </nav>
    </aside>
  );
};

const styles = {
  sidebar: {
    width: "200px",
    backgroundColor: "#454545",
    color: "#fff",
    height: "100vh",
    display: "flex",
    flexDirection: "column",
    padding: "1rem",
  },
  logo: {
    marginBottom: "2rem",
  },
  nav: {
    flexGrow: 1,
  },
};

export default Sidebar;
