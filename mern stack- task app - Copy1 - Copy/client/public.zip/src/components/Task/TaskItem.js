import React from "react";

const TaskItem = ({ task }) => {
  return (
    <div style={styles.taskItem}>
      <strong>{task.category}:</strong> {task.title}
      {/* Display subTasks or a “subtasks count” if desired */}
    </div>
  );
};

const styles = {
  taskItem: {
    padding: "0.5rem",
    marginBottom: "0.5rem",
    border: "1px solid #ddd",
    borderRadius: "4px",
  },
};

export default TaskItem;
