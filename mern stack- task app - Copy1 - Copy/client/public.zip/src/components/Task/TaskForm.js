import React, { useState } from "react";
import axios from "axios";

const TaskForm = () => {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [subTasks, setSubTasks] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/api/tasks", {
        title,
        category,
        subTasks
      });
      console.log("Created:", response.data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Category</label>
        <input
          type="text"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        />
      </div>
      <div>
        <label>Title</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>

      {/* You can add logic to dynamically add subTasks fields */}
      {/* e.g., a simple text input for subtask, push to subTasks array */}

      <button type="submit">Add Task</button>
    </form>
  );
};

export default TaskForm;
