import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Sidebar from "./components/Layout/Sidebar";
import HomePage from "./pages/HomePage";

const App = () => {
  return (
    <Router>
      <div style={{ display: "flex" }}>
        <Sidebar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          {/* You can add other routes for "Settings", "Analytics", etc. */}
        </Routes>
      </div>
    </Router>
  );
};

export default App;
