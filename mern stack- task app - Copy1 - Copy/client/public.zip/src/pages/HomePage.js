import React, { useEffect } from "react";
import TaskList from "../components/Task/TaskList";
import TaskDetail from "../components/Task/TaskDetail"; // hypothetical
import axios from "axios";

const HomePage = () => {

// in HomePage.js or a dedicated component
useEffect(() => {
    const generateTasksIfEmpty = async () => {
      try {
        const today = new Date().toISOString().split("T")[0];
        await axios.post("http://localhost:5000/api/tasks/auto-generate", {
          date: today
        });
      } catch (error) {
        console.error(error);
      }
    };
  
    generateTasksIfEmpty();
  }, []);
  

  return (
    <div style={styles.container}>
      <div style={styles.topBar}>
        <h2>All my tasks</h2>
        <input type="text" placeholder="Filter" style={styles.filterInput} />
      </div>
      <div style={styles.main}>
        <div style={styles.leftPanel}>
          {/* This panel can hold categories or a minimal list of tasks */}
          <TaskList />
        </div>
        <div style={styles.rightPanel}>
          {/* This panel can show detail of a selected task or more advanced features */}
          <TaskDetail />
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    flex: 1,
    padding: "1rem",
  },
  topBar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: "1rem",
  },
  filterInput: {
    padding: "0.5rem",
    borderRadius: "4px",
    border: "1px solid #ccc",
  },
  main: {
    display: "flex",
    gap: "1rem",
  },
  leftPanel: {
    flex: 1,
    backgroundColor: "#f5f5f5",
    padding: "1rem",
    borderRadius: "8px",
  },
  rightPanel: {
    flex: 2,
    backgroundColor: "#fff",
    padding: "1rem",
    borderRadius: "8px",
    border: "1px solid #eee",
  },
};

export default HomePage;
